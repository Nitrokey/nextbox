<?php


namespace OCA\Nextbox\AppInfo;

$app = new Application();


?>
