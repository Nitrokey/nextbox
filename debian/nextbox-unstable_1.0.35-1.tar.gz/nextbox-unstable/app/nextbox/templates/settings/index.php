<div id="app-settings">
	<div id="app-settings-header">
		<button class="settings-button"
				data-apps-slide-toggle="#app-settings-content"
		></button>
	</div>
	<div id="app-settings-content">
	<ul> <li>
		<input type="checkbox" id="expert_mode" class="checkbox">
        <label for="expert_mode">Expert Mode</label><br>
    </li></ul>
	</div>
</div>

