#!/usr/bin/bash

/usr/bin/docker-compose -f docker-compose.yml up


